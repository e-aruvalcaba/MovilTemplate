$(function () {
  'use strict'

  // $('[data-toggle="offcanvas"]').on('click',()=>{
  //   $('.offcanvas-collapse').toggleClass('open');    
  // });
  // $('[data-toggle="tema"]').on('click',()=>{
  //   $('.offcanvas-collapse').toggleClass('open');
    
  // });
});
