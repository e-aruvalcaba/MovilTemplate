(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.logosplash = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC33FF").ss(24,1,1).p("Ab3AAQAALjoKIKQoKIKrjAAQriAAoKoKQoKoKAArjQAAriIKoJQIKoLLiAAQLjAAIKILQIKIJAALig");
	this.shape.setTransform(195.45,178.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FF8E61","#FF5787","#B8CCA2"],[0,0,1],0,0,0,0,0,179.6).s().p("AzrTsQoKoJAArjQAAriIKoKQIKoJLhgBQLiABILIJQIJIKABLiQgBLjoJIJQoLIKriAAQrhAAoKoKg");
	this.shape_1.setTransform(195.45,178.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#CC33FF").ss(24,1,1).p("A72AAQAAlsCAk4QCBk8EDkFQIRoRLiAAQCVAACMAWQFgA1EpC8QCqBrCYCYQBmBmBSBuQFRHGABJRQAAFuiAE4QiAE8kDEFQoSIRriAAQiUAAiNgWQlgg1kpi8QiqhriYiZQhmhmhShuQlSnGAApSg");
	this.shape_2.setTransform(195.45,178.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FF8E61","#FF5787","#B8CCA2"],[0,0,1],0,0,0,0,0,179.7).s().p("AkhbhQlgg2koi7QirhsiYiYQhmhmhShvQlSnFAApSQAAlsCAk4QCAk7EDkGQISoRLhAAQCVAACNAWQFgA2EoC7QCrBsCYCYQBmBlBSBvQFRHFAAJSQAAFth/E4QiBE7kDEFQoRISrigBQiUABiNgWg");
	this.shape_3.setTransform(195.45,178.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#CC33FF").ss(24,1,1).p("A72gBQAAlsCAk4QCBk8EDkFQISoPLiAAQCVAACMAVQFhA2EoC7QCrBsCXCYQBmBmBSBuQFRHGAAJRQAAFuiAE4QiBE7kDEFQoSIQrhAAQiVAAiNgVQlgg2koi8QirhriYiYQhmhmhRhvQlSnHAApRg");
	this.shape_4.setTransform(195.45,178.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#FF8E61","#FF5787","#B8CCA2"],[0,0.004,1],0,0,0,0,0,179.8).s().p("AkibhQlgg2koi8QirhriYiYQhmhmhRhvQlSnHAApRQAAlsCAk4QCBk8EDkFQISoPLhAAQCWAACMAVQFgA2EpC7QCrBsCXCYQBmBmBSBuQFRHGAAJRQAAFuiAE4QiBE7kDEFQoSIQrhAAQiVAAiNgVg");
	this.shape_5.setTransform(195.45,178.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#CB34FE").ss(24,1,1).p("A73gDQAAlsCBk4QCBk8EEkEQIToOLhAAQCVAACNAWQFgA1EpC8QCqBsCYCYQBmBmBRBvQFQHGABJQQAAFviBE4QiCE7kDEFQoTIOriAAQiVAAiMgWQlhg1koi8QirhsiXiYQhmhnhShuQlQnHAApSg");
	this.shape_6.setTransform(195.45,178.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#FE8E61","#FF5787","#B8CCA2"],[0,0.004,1],0,0,0,0,0,180).s().p("AkkbgQlgg1kpi8QirhsiXiYQhmhnhShuQlQnHABpSQgBlsCBk4QCBk8EEkEQIToOLiAAQCUAACOAWQFfA1EpC8QCrBsCXCYQBmBmBRBvQFQHGAAJQQAAFviAE4QiBE7kEEFQoSIOriAAQiVAAiNgWg");
	this.shape_7.setTransform(195.45,178.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#CA35FD").ss(24,1,1).p("A74gGQAAltCCk4QCCk7EEkDQIVoLLiAAQCVAACNAVQFgA1EpC9QCqBsCYCYQBlBnBRBuQFOHIABJRQAAFviCE4QiCE7kEEDQoUILriAAQiVAAiNgVQlhg1koi9QirhsiXiZQhmhmhRhvQlPnIAApSg");
	this.shape_8.setTransform(195.45,178.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["#FD8E61","#FF5887","#B9CBA1"],[0,0.012,1],0,0,0,0,0,180.3).s().p("AkobgQlgg1kpi9QiqhsiXiZQhmhmhRhwQlOnHAApRQgBltCCk5QCCk6EFkDQIToMLjAAQCVAACMAWQFhA0EoC9QCrBsCXCZQBmBmBRBuQFOHIAAJRQAAFuiBE4QiCE8kEECQoVIMriAAQiUAAiOgVg");
	this.shape_9.setTransform(195.45,178.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#C936FC").ss(24,1,1).p("A74gKQAAltCCk4QCDk7EGkBQIVoILjAAQCVAACNAVQFhA0EpC+QCqBsCXCZQBlBnBRBvQFLHIABJRQAAFwiCE4QiEE7kFEBQoWIIriAAQiWAAiMgVQlig1koi9QiqhsiYiaQhlhmhQhwQlMnJAApSg");
	this.shape_10.setTransform(195.45,178);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["#FC8E61","#FF5886","#B9CBA1"],[0,0.016,1],0,0,0,0,0,180.7).s().p("AkrbfQlhg1kpi9QirhsiWiaQhmhmhQhwQlMnJAApSQgBltCDk3QCDk8EGkBQIWoILhAAQCWAACNAVQFhA0EpC+QCqBsCWCaQBmBmBRBwQFLHHABJRQAAFwiDE4QiDE7kGEBQoVIIrjAAQiVAAiMgVg");
	this.shape_11.setTransform(195.45,178);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C738FB").ss(24,1,1).p("A76gPQAAluCEk3QCEk7EHj/QIYoELjAAQCWAACNAVQFiA0EoC/QCqBtCWCZQBlBoBQBvQFJHJAAJSQAAFwiDE3QiFE7kHD/QoYIErjAAQiVAAiNgVQlig1koi+QirhtiWiZQhlhohQhwQlJnKAApSg");
	this.shape_12.setTransform(195.45,177.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["#FB8E61","#FF5886","#BACAA0"],[0,0.024,1],0,0,0,0,0,181.2).s().p("AkybeQlhg1koi+QirhtiWiZQhlhohQhwQlJnKAApSIAAAAQAAluCEk3QCFk7EGj/QIZoELiAAQCWAACMAVQFjA0EnC/QCrBtCWCZQBlBoBQBvQFIHJABJSQAAFwiEE3QiEE7kHD/QoYIErjAAQiVAAiOgVg");
	this.shape_13.setTransform(195.45,177.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#C53AF9").ss(24,1,1).p("A78gWQAAluCFk3QCHk7EJj8QIan+LkAAQCVAACOAVQFiAzEoC/QCrBuCVCbQBkBoBPBvQFGHMAAJSQAAFwiFE4QiHE6kID8QobH+rkAAQiVAAiOgUQlig0koi/QirhuiViaQhkhohPhxQlGnMAApTg");
	this.shape_14.setTransform(195.475,177.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#FA8E61","#FF5986","#BBCAA0"],[0,0.035,1],0,0,0,0,0,181.9).s().p("Ak5bcQligzkojAQirhuiViZQhkhohPhxQlGnMAApTQAAluCFk4QCHk6EJj8QIan+LkAAQCVAACOAVQFiA0EoC/QCrBtCVCbQBkBnBPBwQFGHMAAJSQAAFwiFE4QiHE6kID8QobH+rkAAQiVAAiOgVg");
	this.shape_15.setTransform(195.475,177.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#C23DF7").ss(24,1,1).p("A7/geQAAlvCIk3QCJk7EKj4QIfn3LkAAQCWAACOAUQFjAzEoDBQCrBvCUCbQBjBoBOBxQFBHOAAJSQAAFxiHE3QiJE7kKD4QogH3rkAAQiVAAiOgUQljgzkpjBQiqhuiUicQhkhohNhxQlCnQAApSg");
	this.shape_16.setTransform(195.5,177.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["#F88E61","#FF5A85","#BCC99F"],[0,0.051,1],0,0,0,0,0,182.8).s().p("AlCbbQljg0kpjAQiqhviUibQhkhohNhxQlBnPAApTQAAlvCHk3QCJk7ELj4QIen3LkAAQCWAACOAVQFiAzEpDAQCqBvCUCbQBkBpBOBwQFBHOABJSQgBFxiHE3QiJE6kKD5QofH3rlAAQiVAAiOgUg");
	this.shape_17.setTransform(195.5,177.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#BF40F5").ss(24,1,1).p("A8CgpQAAlvCLk3QCLk6ENj1QIknuLlAAQCWAACOAUQFkAyEoDDQCrBwCTCcQBiBpBNByQE7HRABJTQAAFxiLE3QiME6kMD1QokHurlAAQiWAAiOgUQlkgykpjDQiqhwiTicQhihphNhyQk8nSAApUg");
	this.shape_18.setTransform(195.5,177.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#F58E62","#FF5B84","#BDC89E"],[0,0.067,1],0,0,0,0,0,183.9).s().p("AlNbZQlkgzkpjCQiqhwiSicQhjhphNhzQk8nRAApUQAAlwCLk2QCMk6EMj0QIknvLlAAQCWABCOATQFkAyEoDDQCrBwCTCcQBiBpBNByQE7HRAAJTQAAFxiKE3QiLE6kOD1QojHurlAAQiWgBiOgTg");
	this.shape_19.setTransform(195.5,177.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#BA45F2").ss(24,1,1).p("A8Fg1QAAlxCOk3QCOk5ERjvQIpnkLmAAQCWAACPAUQFlAxEoDEQCrByCRCdQBiBrBLBzQE0HUAAJUQAAFziOE2QiOE5kRDvQooHkrmAAQiXAAiPgUQllgxkojFQirhxiRidQhhhqhLh0Qk1nVAApUg");
	this.shape_20.setTransform(195.5,176.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["#F28E62","#FF5C84","#BEC79C"],[0,0.086,1],0,0,0,0,0,185.2).s().p("AlbbVQllgwkojFQirhxiRidQhhhrhLhzQk1nVAApUQAAlyCOk2QCPk6EQjuQIpnkLmAAQCWAACPAUQFlAxEoDEQCrByCRCeQBiBpBKBzQE1HVAAJTQAAF0iNE1QiQE6kQDvQooHkrmgBQiXAAiPgUg");
	this.shape_21.setTransform(195.5,176.95);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#B54AEE").ss(24,1,1).p("A8KhFQAAlzCSk1QCTk5EUjpQIwnWLnAAQCXAACPATQFnAwEoDHQCrBzCPCfQBgBrBJB1QEsHZABJUQAAF0iTE2QiSE5kVDpQovHWroAAQiXAAiPgUQlngvkojHQirhziPifQhghshJh1QksnZAApVg");
	this.shape_22.setTransform(195.55,176.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["#EE8E62","#FF5D83","#C0C59B"],[0,0.11,1],0,0,0,0,0,186.8).s().p("AlrbSQlogvkojHQirhziPifQhfhrhKh2QkrnZAApVQgBlzCSk1QCTk5EUjpQIwnWLnAAQCXABCQASQFmAwEpDIQCqByCPCfQBgBsBJB0QEsHZABJVQAAFziTE3QiSE5kVDnQovHWroAAQiXABiOgUg");
	this.shape_23.setTransform(195.55,176.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#AF50E9").ss(24,1,1).p("A8PhZQAAl0CXk1QCYk4EZjgQI4nGLpAAQCXAACQASQFpAuEoDLQCrB0CMCiQBfBsBGB3QEiHeAAJWQAAF2iXE1QiYE4kZDgQo4HGrpAAQiXAAiQgSQlpgukojLQirh0iMiiQhfhshGh3QkinfAApWg");
	this.shape_24.setTransform(195.55,176.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["#EA8E62","#FF5F82","#C2C399"],[0,0.141,1],0,0,0,0,0,188.8).s().p("AmAbPQlpgvkojKQirh0iMiiQhfhshGh4QkineAApXIAAAAQAAl0CXk0QCYk5EZjgQI4nGLpAAQCXAACQATQFpAuEoDKQCrB0CNCiQBeBtBGB2QEiHeAAJWQAAF2iXE1QiYE4kZDgQo4HGrpAAQiXAAiQgSg");
	this.shape_25.setTransform(195.55,176.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#A758E3").ss(24,1,1).p("A8WhxQAAl1Cdk1QCfk3EfjXQJCmxLrAAQCYAACRARQFrAsEoDPQCrB3CJCkQBdBuBDB5QEVHlAAJXQAAF3idE1QieE3kfDWQpDGyrrAAQiYAAiRgRQlrgskojPQirh3iJikQhchuhEh5QkVnmAApYg");
	this.shape_26.setTransform(195.575,175.525);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["#E48E63","#FF6180","#C5C196"],[0,0.18,1],0,0,0,0,0,191.2).s().p("AmabKQlrgskojPQirh3iJikQhchuhEh5QkVnmAApYQAAl1Cdk1QCfk3EfjXQJCmxLrAAQCYAACRARQFrAsEoDPQCrB3CJCkQBdBuBDB5QEVHlAAJXQAAF3idE1QieE3kfDWQpDGyrrAAQiYAAiRgRg");
	this.shape_27.setTransform(195.575,175.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#9E61DC").ss(24,1,1).p("A8eiPQAAl4Clk0QCmk2EmjKQJPmYLuAAQCZAACSAQQFuAqEnDTQCsB7CFCnQBaBwA/B7QEFHuAAJZQAAF5ilE0QimE3kmDKQpPGYruAAQiZAAiSgRQlugpkojUQirh6iFimQhahxg/h8QkFnuAApag");
	this.shape_28.setTransform(195.625,174.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.rf(["#DD8E63","#FF647E","#C8BE93"],[0,0.227,1],0,0,0,0,0,194.3).s().p("Am6bDQlugpkojUQirh6iFimQhahxg/h8QkFnuAApZQAAl4Clk0QCmk2EmjKQJPmZLuAAQCZAACSAQQFuAqEnDTQCsB7CFCnQBaBwA/B8QEFHtAAJZQAAF5ilE0QimE3kmDKQpPGYruAAQiZAAiSgRg");
	this.shape_29.setTransform(195.625,174.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#916ED3").ss(24,1,1).p("A8pi1QAAl7CvkyQCwk1Evi6QJgl5LxAAQCZAACUAPQFyAmEnDaQCsB+CACrQBXB0A6B+QDxH4AAJcQAAF8ivEzQiwE0kvC7QpgF5rxAAQiZAAiUgPQlygnknjaQish9iAirQhXh0g6h/Qjxn5AApbg");
	this.shape_30.setTransform(195.675,173.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.rf(["#D48D64","#FF677C","#CCBA8F"],[0,0.286,1],0,0,0,0,0,198.1).s().p("Ania7QlygmknjZQish/iAiqQhXhzg6iAQjxn4AApcIAAAAQAAl8CvkyQCwk1Evi6QJgl5LxAAQCZAACUAPQFyAnEnDZQCsB+CACsQBXBzA6B/QDxH3AAJcQAAF8ivEyQiwE2kvC6QpgF5rxAAQiZAAiUgQg");
	this.shape_31.setTransform(195.675,173.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#827DC7").ss(24,1,1).p("A83jkQAAl/C8kxQC8kzE7inQJ1lRL0AAQCbAACVAOQF3AiEnDiQCsCDB6CwQBTB3A0CDQDXIGABJeQgBGAi7EwQi8E0k7CnQp1FRr0AAQibAAiWgOQl2giknjiQisiDh6ivQhTh3g0iFQjYoGAApdg");
	this.shape_32.setTransform(195.725,172.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.rf(["#C98D65","#FF6B79","#D2B68A"],[0,0.365,1],0,0,0,0,0,202.9).s().p("AoVayQl2giknjiQisiEh6ivQhTh3g0iDQjYoGAApeIAAgBQAAl+C8kyQC8kzE7inQJ1lRL0AAQCbAACVAOQF3AjEnDhQCsCEB6CwQBTB2A0CDQDXIFABJeQgBGBi7ExQi8Ezk7CmQp1FRr0ABQibAAiWgOg");
	this.shape_33.setTransform(195.725,172.75);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#6F90B9").ss(24,1,1).p("A9HkeQAAmDDLkwQDLkxFKiOQKNkhL5AAQCdAACXAMQF9AdEnDrQCsCKBzC2QBNB7AtCIQC4IXAAJhQAAGFjKEvQjMExlJCOQqOEhr5AAQicAAiYgMQl9gdkmjrQitiKhyi1QhOh8gtiIQi4oWAApjg");
	this.shape_34.setTransform(195.8,171.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.rf(["#BB8D66","#FF7076","#D8B084"],[0,0.455,1],0,0,0,0,0,208.9).s().p("ApSamQl9gdkmjsQitiJhyi1QhOh7gtiJQi4oXAAphIAAgBQAAmDDKkvQDLkyFLiOQKNkhL5AAQCcAACYAMQF8AdEnDsQCtCJByC2QBOB7AtCIQC3IWABJiQAAGEjKEwQjMExlKCPQqNEfr6ABQibAAiYgMg");
	this.shape_35.setTransform(195.8,171.35);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#5BA4AA").ss(24,1,1).p("A9ZleQAAmIDbkuQDckuFZh0QKqjrL+AAQCeAACaAJQGDAYEmD2QCtCQBrC9QBIB/AkCPQCWIoAAJlQAAGJjbEtQjcEvlZB0QqqDrr/AAQidAAibgJQmCgYknj2QisiQhqi8QhJiAgkiPQiWooAAplg");
	this.shape_36.setTransform(195.875,169.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.rf(["#AC8D67","#FF7672","#DFAA7E"],[0,0.557,1],0,0,0,0,0,215.4).s().p("AqXaZQmCgYknj2QisiQhqi8QhJiAgkiPQiWooAAplIAAgBQAAmIDbkuQDckuFZh0QKqjrL+AAQCeAACaAJQGDAYEmD2QCtCQBrC9QBIB/AkCPQCWIoAAJlQAAGJjbEtQjcEvlZB0QqqDrr/AAQidAAibgJg");
	this.shape_37.setTransform(195.875,169.825);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#47B89B").ss(24,1,1).p("A9rmaQAAmNDrksQDsktFohbQLEi4MEAAQCgAACcAIQGJASEmEAQCsCXBjDDQBDCEAdCUQB1I5ABJpQgBGOjrErQjrEtlpBbQrDC4sEAAQifAAidgIQmJgSkmkBQisiWhjjCQhEiEgciVQh2o5AAppg");
	this.shape_38.setTransform(195.95,168.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.rf(["#9D8D68","#FF7B6E","#E6A478"],[0,0.651,1],0,0,0,0,0,221.6).s().p("ArXaMQmJgSkmkBQisiWhjjCQhEiEgciVQh1o5AAppIAAAAQgBmNDsksQDrktFohbQLEi4MEAAQCgAACcAIQGIASEnEAQCsCXBjDDQBDCEAdCUQB1I5ABJpQgBGOjrErQjrEtlpBbQrDC4sEAAQifAAidgIg");
	this.shape_39.setTransform(195.95,168.375);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#37C88F").ss(24,1,1).p("A95nNQAAmRD4kqQD5kqF1hHQLaiOMIAAQCgAACeAGQGOAOEmEJQCtCcBcDIQA/CHAWCZQBbJHAAJsQAAGSj5EpQj4Erl1BHQrZCOsJAAQigAAifgGQmNgPkmkIQitichcjGQg/iJgWiZQhbpHAApsg");
	this.shape_40.setTransform(196,167.175);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.rf(["#918D68","#FF7F6B","#EC9F72"],[0,0.733,1],0,0,0,0,0,226.7).s().p("AsNaCQmNgPkmkIQisichdjGQg/iJgWiZQhbpHAApsIAAgBQAAmRD4kqQD5kqF1hHQLZiOMJAAQCgAACeAGQGOAOEmEJQCtCcBcDIQA/CHAWCZQBaJHABJsQgBGSj4EpQj4Erl1BHQrZCOsIAAQihAAifgGg");
	this.shape_41.setTransform(196,167.175);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#2AD586").ss(24,1,1).p("A+En0QAAmUECkpQEDkpF/g2QLqhtMLAAQCiAACgAEQGSALElEPQCtCgBYDMQA7CLASCcQBFJSAAJuQAAGVkDEpQkCEpl/A2QrqBtsMAAQiiAAiggEQmRgLkmkQQisifhYjLQg8iLgRidQhFpSAApug");
	this.shape_42.setTransform(196.05,166.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.rf(["#888C69","#FF8369","#F09B6E"],[0,0.792,1],0,0,0,0,0,230.7).s().p("As3Z6QmRgLkmkQQisifhYjLQg7iLgRidQhGpSAApuIAAgBQAAmUEDkpQEDkpF+g2QLrhtMLAAQChAACgAEQGSALEmEPQCsCgBYDMQA7CLASCcQBFJSAAJuQAAGVkDEpQkCEpl/A2QrqBtsMAAQihAAihgEg");
	this.shape_43.setTransform(196.05,166.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#20DF7E").ss(24,1,1).p("A+NoTQAAmXELkoQELkoGGgpQL4hTMNAAQCjAAChADQGVAJElEUQCtCjBUDPQA5CNANCfQA1JbAAJwQgBGYkKEnQkLEomGApQr3BUsOAAQijAAihgEQmVgIklkVQitiihTjOQg5iNgNigQg2pbAApwg");
	this.shape_44.setTransform(196.075,165.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.rf(["#818C69","#FF8567","#F4986B"],[0,0.843,1],0,0,0,0,0,233.8).s().p("AtXZ0QmVgJklkVQitiihTjOQg5iOgNifQg2pbAApwIAAgBQAAmXELkoQELkoGGgoQL4hUMNAAQCjAAChAEQGVAIElEUQCtCjBUDQQA5CMANCfQA1JbAAJwQgBGYkKEmQkLEpmGApQr3BUsOAAQijAAihgDg");
	this.shape_45.setTransform(196.075,165.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#18E778").ss(24,1,1).p("A+TorQAAmYEQknQERkoGMgfQMDg/MQAAQCjAACiACQGXAHElEYQCtCmBQDRQA3CPAKChQAoJiAAJxQAAGZkQEnQkREnmMAgQsCA/sRAAQiiAAiigDQmYgGklkYQitilhQjRQg3iPgKiiQgopiAApxg");
	this.shape_46.setTransform(196.1,164.925);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.rf(["#7B8C6A","#FF8766","#F79569"],[0,0.878,1],0,0,0,0,0,236.2).s().p("AtxZuQmWgGkmkYQitilhQjRQg3iPgKiiQgopiAApxIAAgBQAAmYEQknQERkoGMgfQMDg/MPAAQCjAACiACQGXAHElEYQCuCmBQDRQA3CPAKChQAoJiAAJxQAAGZkQEnQkSEnmMAgQsBA/sQAAQikAAiigDg");
	this.shape_47.setTransform(196.1,164.925);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#12ED74").ss(24,1,1).p("A+Zo9QAAmaEWknQEWknGRgXQMKgwMRAAQCkAACjACQGZAFEkEbQCuCoBODUQA1CQAICiQAeJoAAJzQAAGakWEmQkWEnmQAXQsKAwsSAAQikAAijgCQmYgFkmkbQitinhNjTQg2iQgHikQgfpnAApzg");
	this.shape_48.setTransform(196.125,164.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.rf(["#768C6A","#FF8964","#F99467"],[0,0.91,1],0,0,0,0,0,238.1).s().p("AuFZrQmYgFkmkcQitinhNjSQg2iRgHijQgfpnAApzIAAAAQAAmaEWknQEWkmGRgYQMKgwMRAAQCkAACjACQGZAFEkEbQCuCpBODTQA1CQAICiQAeJnAAJ0QAAGakWEmQkWEnmQAXQsKAvsSAAQikAAijgBg");
	this.shape_49.setTransform(196.125,164.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#0EF170").ss(24,1,1).p("A+dpMQAAmcEakmQEakmGUgRQMRgjMSAAQCkAACkABQGaAEElEeQCuCpBMDVQA0CRAFCkQAWJsAAJzQAAGckaElQkZEnmVARQsQAjsTAAQikAAijgBQmbgEklkeQitiohMjUQg0iSgFilQgXprAAp0g");
	this.shape_50.setTransform(196.15,164.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.rf(["#738C6A","#FF8A64","#FA9265"],[0,0.933,1],0,0,0,0,0,239.7).s().p("AuUZnQmbgDklkeQitiphMjTQg1iSgEimQgXpqAAp0IAAAAQAAmcEakmQEZkmGVgRQMRgjMSAAQCkAACkACQGaADEkEeQCuCpBNDVQA0CRAEClQAXJrAAJzQAAGckaElQkZEmmVASQsQAjsTAAQikAAijgCg");
	this.shape_51.setTransform(196.15,164.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#0AF56D").ss(24,1,1).p("A+hpYQAAmcEdkmQEdkmGXgMQMWgZMUAAQClAACjABQGcACElEgQCtCrBKDWQA0CSADClQARJvAAJ0QgBGdkcEkQkdEnmXAMQsWAZsUAAQikAAikgBQmcgCklkgQitiqhKjVQg0iTgDimQgRpuAAp0g");
	this.shape_52.setTransform(196.15,163.825);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.rf(["#708C6B","#FF8B63","#FC9164"],[0,0.953,1],0,0,0,0,0,240.9).s().p("AuhZlQmbgCkmkgQisiqhLjVQgziTgEimQgQpuAAp0IAAgBQgBmcEekmQEdkmGWgMQMXgZMTAAIFIABQGbACEmEgQCtCrBKDWQA0CSADClQAQJvABJ0QgBGdkdEkQkcEnmYAMQsVAZsUAAIlIgBg");
	this.shape_53.setTransform(196.15,163.825);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#07F86B").ss(24,1,1).p("A+jphQAAmdEfkmQEgklGZgJQMagRMUAAQClAACkABQGcABElEhQCuCsBJDXQAyCTADCmQALJyAAJ0QAAGekfEkQkgEmmZAJQsZARsVAAQilAAikgBQmcgBklkiQitirhJjVQgziUgDinQgLpxAAp0g");
	this.shape_54.setTransform(196.175,163.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.rf(["#6E8C6B","#FF8C62","#FD9063"],[0,0.969,1],0,0,0,0,0,241.8).s().p("AurZjQmcgBklkiQitirhJjVQgziUgDinQgLpxAAp0IAAgBQAAmdEfklQEgkmGZgJQMagRMUAAIFJABQGcABElEiQCuCsBJDXQAyCSADCmQALJxAAJ1QAAGdkfElQkgEmmZAIQsZASsVAAIlJgBg");
	this.shape_55.setTransform(196.175,163.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#04FB69").ss(24,1,1).p("A+lpoQAAmeEhklQEhklGbgGQMegLMUAAQClAAClAAQGdABEkEjQCuCsBIDYQAyCTACCnQAHJzAAJ1QAAGekhElQkhElmbAGQsdALsVAAQilAAikAAQmdgBkmkjQisishJjWQgyiUgCioQgHpzAAp0g");
	this.shape_56.setTransform(196.175,163.425);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.rf(["#6C8C6B","#FF8D62","#FD8F62"],[0,0.976,1],0,0,0,0,0,242.5).s().p("AuyZiQmdgBkmkjQisishJjWQgyiUgCioQgHpzAAp0IAAgBQAAmeEhklQEhklGbgGQMegLMUAAIFKAAQGdABEkEjQCuCsBIDYQAyCTACCnQAHJzAAJ1QAAGekhElQkhElmbAGQsdALsVAAIlJAAg");
	this.shape_57.setTransform(196.175,163.425);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#03FC68").ss(24,1,1).p("A+npuQAAmeEiklQEjklGdgDQMggHMVAAQClAACkAAQGeABElEjQCtCtBIDZQAxCTABCnQAFJ1AAJ2QgBGekiElQkiElmdADQsfAHsWAAQilAAikAAQmegBklkjQitithIjXQgxiVgBioQgFp0AAp1g");
	this.shape_58.setTransform(196.2,163.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.rf(["#6B8C6B","#FF8D62","#FE8F62"],[0,0.988,1],0,0,0,0,0,243.1).s().p("Au4ZgQmeAAklkjQitithHjXQgyiVgCinQgDp0AAp1IAAgBQAAmfEhklQEkklGcgDQMfgHMWAAIFJABQGeAAElEjQCtCtBIDZQAxCUABCmQAFJ1gBJ1QAAGfkiElQkjEkmcAEQsfAHsWAAIlJgBg");
	this.shape_59.setTransform(196.2,163.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#01FE67").ss(24,1,1).p("A+opxQAAmeEkkmQEkkkGdgDQMhgDMWAAQClAACkAAQGeABElEjQCuCuBHDZQAxCUABCnQACJ2AAJ2QgBGekjElQkjElmeACQsgADsWAAQilAAilAAQmeAAklkkQitithHjXQgyiVAAipQgDp1AAp1g");
	this.shape_60.setTransform(196.175,163.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.rf(["#6A8C6B","#FF8E61","#FE8E61"],[0,0.992,1],0,0,0,0,0,243.5).s().p("Au8ZgQmegBklkjQitithHjXQgyiWAAioQgDp1AAp2IAAgBQAAmdEkklQEkkmGdgBQMhgEMWAAIFJAAQGeAAElEkQCuCuBHDZQAxCTABCoQACJ2AAJ1QgBGfkjEkQkjEmmeACQsgADsWAAIlKAAg");
	this.shape_61.setTransform(196.175,163.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#01FE66").ss(24,1,1).p("A+pp0QAAmfEkklQElkkGegBQMigCMWAAQClAAClAAQGeAAElElQCuCtBHDaQAwCUAACnQACJ3AAJ2QgBGfkkEkQkkElmeABQsiACsWAAQilAAilAAQmfgBklkkQitiuhGjXQgxiVgBipQgBp1AAp2g");
	this.shape_62.setTransform(196.2,163.15);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.rf(["#698C6B","#FF8E61","#FF8E61"],[0,0.996,1],0,0,0,0,0,243.7).s().p("Au/ZgQmegBkmkkQitiuhGjXQgxiVAAipIgBzrIAAgBQgBmfEkkkQElklGegBIY4gCIFKAAQGfAAEkElQCuCtBHDaQAwCUAACoIABTsQAAGfkkEkQkkElmeABI44ACIlKAAg");
	this.shape_63.setTransform(196.2,163.15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#00FF66").ss(24,1,1).p("A+pp2QAAmeEkklQEmkkGeAAQMjgBMWAAQClAAClAAQGeAAElEkQCuCuBGDaQAxCUAACoQAAJ2AAJ3QAAGeklElQkkEkmfABQsiAAsWAAQilAAilAAQmfAAklklQitithHjXQgwiVAAipQgBp3AAp1g");
	this.shape_64.setTransform(196.2,163.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.rf(["#698C6B","#FF8E61","#FF8E61"],[0,1,1],0,0,0,0,0,243.9).s().p("Ap3ZfIlJAAQmfAAklklQitithHjYQgxiVABioIgBzsIAAgBQAAmfEkklQElkkGfAAIY5gBIFJAAQGfAAElEkQCtCvBHDZQAwCUAACoIABTtQAAGfklEjQkkElmfABI45AAg");
	this.shape_65.setTransform(196.2,163.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#00FF66").ss(24,1,1).p("AvB5eIeDAAQGeAAElEkQElEmAAGeIAATtQAAGfklEkQklElmeAAI+DAAQmeAAkmklQkkkkAAmfIAAztQAAmeEkkmQEmkkGeAAg");
	this.shape_66.setTransform(196.2,163.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.rf(["#698C6B","#FF8E61"],[0,1],0,0,0,0,0,243.9).s().p("AvBZfQmfAAkkklQklkkAAmfIAAztQAAmfElkkQEkklGfAAIeDAAQGeAAElElQElEkAAGfIAATtQAAGfklEkQklElmeAAg");
	this.shape_67.setTransform(196.2,163.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#09F66C").ss(24,1,1).p("A+ipcQAAmcEekmQEeklGYgLQMYgWMUAAQCkAACkABQGcACElEgQCtCrBLDXQAyCSADCmQAPJvAAJ1QgBGdkdEkQkeEmmYALQsXAWsVAAQikAAikgBQmcgCklkgQitirhKjVQgziTgDinQgPpvAAp0g");
	this.shape_68.setTransform(196.15,163.725);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.rf(["#6F8C6B","#FF8C63","#FC9164"],[0,0.957,1],0,0,0,0,0,241.2).s().p("AulZkQmcgCklkgQisirhLjVQgziTgDinQgOpvAAp0IAAgBQgBmcEfkmQEdklGZgLQMXgWMUAAIFIABQGcACElEgQCtCrBLDXQAyCSAECmQAOJvgBJ1QAAGdkeEkQkdEmmYALQsXAWsUAAIlJgBg");
	this.shape_69.setTransform(196.15,163.725);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#11EE73").ss(24,1,1).p("A+apCQAAmaEWkmQEYknGRgWQMMgsMSAAQCkAACjACQGZAEElEcQCuCpBNDUQA1CQAHCjQAcJpAAJzQAAGbkYElQkWEnmSAWQsLAssTAAQijAAijgCQmagEklkcQitiphNjSQg1iRgHikQgcpoAApzg");
	this.shape_70.setTransform(196.15,164.35);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.rf(["#758C6A","#FF8964","#F99366"],[0,0.918,1],0,0,0,0,0,238.6).s().p("AuJZqQmagFklkcQisinhOjTQg1iRgHikQgcpoAApzIAAgBQAAmaEXkmQEXkmGRgWQMNgsMRgBQCkAACjACQGZAFElEbQCtCpBODUQA1CQAHCkQAcJnAAJ0QAAGakYEmQkWEnmRAVQsNAtsRgBQikABijgCg");
	this.shape_71.setTransform(196.15,164.35);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#1AE679").ss(24,1,1).p("A+TonQAAmZEQknQERknGLghQMAhCMQAAQCjAACiACQGXAHElEYQCuClBQDSQA3COALChQAqJhAAJxQgBGZkPEnQkREnmLAhQsABCsQAAQijAAiigDQmXgGklkYQisilhSjQQg3iPgKiiQgrphAApxg");
	this.shape_72.setTransform(196.1,165);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.rf(["#7C8C6A","#FF8766","#F69669"],[0,0.875,1],0,0,0,0,0,235.9).s().p("AttZvQmXgGklkZQisikhRjQQg4iPgKiiQgqphAApwIAAgBQAAmYEPkoQERknGLghQMBhCMPAAQCjAACiADQGXAGElEYQCtClBRDSQA3COAKChQAqJhABJxQgBGZkPEmQkQEomLAhQsBBCsQAAQijAAiigDg");
	this.shape_73.setTransform(196.1,165);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#22DD80").ss(24,1,1).p("A+LoNQAAmWEJkoQEJkoGFgsQL1hYMOAAQCiAAChADQGUAJElETQCuCjBUDPQA5CMAOCeQA4JaAAJvQAAGXkJEoQkJEomFAsQr1BYsOAAQiiAAihgDQmUgJkmkUQisiihUjNQg6iNgOifQg4paAApvg");
	this.shape_74.setTransform(196.075,165.625);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.rf(["#828C69","#FF8567","#F3986C"],[0,0.831,1],0,0,0,0,0,233.2).s().p("AtRZ1QmUgJkmkUQisiihUjNQg6iNgOifQg4paAApvIAAgBQAAmWEJkoQEJkoGFgsQL1hYMOAAQCiAAChADQGUAJElETQCuCjBUDPQA5CMAOCeQA4JaAAJvQAAGXkJEoQkJEomFAsQr1BYsOAAQiiAAihgDg");
	this.shape_75.setTransform(196.075,165.625);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#2AD586").ss(24,1,1).p("A+EnzQAAmUECkpQEDkpF+g3QLqhuMLAAQCiAACgAFQGRALElEPQCuCgBYDMQA7CKARCcQBHJSAAJuQgBGVkCEpQkCEpl+A3QrqBusMAAQihAAiggFQmSgLklkPQitighXjKQg8iMgSicQhGpSAAptg");
	this.shape_76.setTransform(196.05,166.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.rf(["#888C69","#FF8369","#F09B6F"],[0,0.792,1],0,0,0,0,0,230.5).s().p("As1Z6QmRgLkmkPQitighXjKQg8iLgRidQhGpSgBpuIAAgBQABmUECkpQECkpF/g3QLphtMLgBQCiABCgAEQGRALElEPQCuCgBXDMQA8CKARCcQBHJSAAJuQgBGVkCEoQkDEql9A2QrqBusMAAQihABiggFg");
	this.shape_77.setTransform(196.05,166.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#33CC8C").ss(24,1,1).p("A98nZQAAmSD7kpQD8krF4hBQLeiEMJAAQChAACfAFQGPAOElEKQCtCdBbDJQA+CJAVCZQBUJLAAJtQAAGSj8EpQj7Erl4BCQreCEsJAAQihAAifgFQmPgOkmkKQisidhbjIQg+iKgViaQhUpKAAptg");
	this.shape_78.setTransform(196.025,166.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.rf(["#8F8D69","#FF806B","#ED9E71"],[0,0.749,1],0,0,0,0,0,227.9).s().p("AsZaAQmPgOkmkKQisidhbjIQg+iKgViaQhUpKAAptIAAgBQAAmRD7kqQD8kqF4hCQLeiEMJAAQChAACfAFQGPAOElEKQCtCdBbDJQA+CJAVCZQBUJLAAJsQAAGTj8EpQj7Erl4BCQreCEsJAAQihAAifgFg");
	this.shape_79.setTransform(196.025,166.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#3CC393").ss(24,1,1).p("A91m+QAAmQD1kqQD1ksFxhMQLTiaMHAAQCgAACeAGQGMAQEmEFQCtCbBeDGQBACHAYCXQBjJDAAJrQgBGRj0EqQj1EslxBMQrTCasHAAQigAAiegGQmMgQkmkGQisiahfjFQhAiHgYiYQhjpDAAprg");
	this.shape_80.setTransform(195.975,167.525);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.rf(["#958D68","#FF7E6C","#EAA074"],[0,0.71,1],0,0,0,0,0,225.2).s().p("Ar9aFQmMgQkmkGQisiahfjFQhAiHgYiYQhjpDAAprIAAgBQAAmQD1kqQD1ksFxhMQLTiaMHAAQCgAACeAGQGMAQEmEFQCtCbBeDGQBACHAYCXQBjJDAAJrQgBGRj0EqQj1EslxBMQrTCasHAAQigAAiegGg");
	this.shape_81.setTransform(195.975,167.525);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#44BB99").ss(24,1,1).p("A9tmkQAAmODtkrQDvksFqhXQLIixMFAAQCfAACdAHQGKASEmECQCsCYBiDDQBCCFAcCVQBwI8AAJpQAAGPjtEqQjuEtlrBXQrHCxsFAAQigAAidgHQmKgSklkCQitiYhhjCQhDiFgciWQhwo8AAppg");
	this.shape_82.setTransform(195.95,168.15);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.rf(["#9B8D68","#FF7C6E","#E7A377"],[0,0.667,1],0,0,0,0,0,222.5).s().p("ArhaLQmKgSkmkDQisiWhijDQhCiGgbiVQhxo8AAppIAAgBQAAmNDuksQDtksFrhXQLIiwMFgBQCfAACdAIQGJAREmECQCtCYBiDDQBCCFAcCVQBwI7AAJqQAAGPjtEqQjvEtlqBXQrHCxsFAAQiggBidgGg");
	this.shape_83.setTransform(195.95,168.15);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#4DB39F").ss(24,1,1).p("A9mmJQAAmMDnksQDnktFkhiQK9jHMCAAQCfAACcAIQGHAUEmD+QCtCVBlDBQBECCAfCTQB+I0ABJoQgBGNjmErQjnEtlkBjQq8DGsDAAQifAAicgIQmHgUkmj+QisiUhljAQhFiDgfiUQh/o0AApog");
	this.shape_84.setTransform(195.925,168.775);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.rf(["#A18D67","#FF796F","#E4A579"],[0,0.624,1],0,0,0,0,0,219.8).s().p("ArFaQQmHgUkmj+QisiUhljAQhFiDgfiUQh/o0AApoIAAAAQAAmMDnksQDnktFkhiQK9jHMCAAQCfAACcAIQGHAUEmD+QCtCVBlDBQBECCAfCTQB+I0ABJoQgBGNjmErQjnEtlkBjQq8DGsDAAQifAAicgIg");
	this.shape_85.setTransform(195.925,168.775);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#55AAA6").ss(24,1,1).p("A9elvQAAmKDgktQDgkuFehtQKxjcMAAAQCeAACbAJQGEAWEnD5QCsCSBpC+QBGCBAiCQQCNItAAJmQAAGLjgEsQjgEvleBtQqwDcsBAAQieAAibgJQmEgWknj5QisiShoi9QhHiCgiiQQiNotAApng");
	this.shape_86.setTransform(195.875,169.425);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.rf(["#A88D67","#FF7771","#E1A87C"],[0,0.584,1],0,0,0,0,0,217.1).s().p("AqpaVQmEgWknj5QisiShoi9QhHiCgiiQQiNotAApnIAAAAQAAmKDgktQDgkuFehtQKxjcMAAAQCeAACbAJQGEAWEnD5QCsCSBpC+QBGCBAiCQQCNItAAJmQAAGLjgEsQjgEvleBtQqwDcsBAAQieAAibgJg");
	this.shape_87.setTransform(195.875,169.425);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#5DA2AC").ss(24,1,1).p("A9XlVQAAmIDZktQDakvFXh4QKljzL+AAQCeAACaAKQGBAZEnD0QCsCQBsC7QBJB/AmCNQCaImABJlQgBGJjZEtQjZEvlXB4QqlDzr/AAQidAAiagKQmCgZkmj1QisiPhsi7QhJh/gmiOQibolAApmg");
	this.shape_88.setTransform(195.875,170.05);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.rf(["#AE8D66","#FF7572","#DEAA7F"],[0,0.541,1],0,0,0,0,0,214.5).s().p("AqNabQmCgZkmj0QisiQhsi7QhJh/gmiOQibomAAplIAAAAQAAmHDZkuQDakvFXh4QKljzL+AAQCeAACaAKQGBAZEnD0QCsCQBsC8QBJB+AmCOQCaIlABJlQgBGIjZEuQjZEvlXB4QqlDyr/ABQidAAiagKg");
	this.shape_89.setTransform(195.875,170.05);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#6699B3").ss(24,1,1).p("A9Pk6QAAmGDSkuQDTkwFQiDQKakJL8AAQCdAACZALQF/AbEnDwQCsCNBvC4QBLB9ApCLQCpIeAAJkQAAGGjSEuQjSExlRCCQqaEJr8AAQidAAiZgLQl/gbknjwQiriMhwi4QhLh+gpiLQipofAApjg");
	this.shape_90.setTransform(195.825,170.675);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.rf(["#B48D66","#FF7374","#DCAD82"],[0,0.502,1],0,0,0,0,0,211.8).s().p("ApxagQl/gbknjwQiriMhwi4QhLh+gpiLQipofAApjIAAAAQAAmGDSkuQDTkwFQiDQKakJL8AAQCdAACZALQF/AbEnDwQCsCNBvC4QBLB9ApCLQCpIeAAJkQAAGGjSEuQjSExlRCCQqaEJr8AAQidAAiZgLg");
	this.shape_91.setTransform(195.825,170.675);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#6F90B9").ss(24,1,1).p("A9IkgQAAmEDMkvQDLkxFLiOQKOkeL6AAQCcAACYALQF9AdEmDsQCsCKBzC2QBNB7AtCJQC3IWAAJiQAAGFjLEuQjMEylKCNQqPEfr5AAQidAAiYgMQl8gcknjtQisiJhyi1QhOh8gsiJQi4oXAApig");
	this.shape_92.setTransform(195.775,171.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.rf(["#BA8D66","#FF7076","#D9B084"],[0,0.459,1],0,0,0,0,0,209.1).s().p("ApVamQl8gdknjtQisiJhyi1QhOh8gsiJQi4oXAAphIAAgBQAAmDDMkwQDLkxFLiOQKOkeL6AAQCcAACYAMQF9AcEmDsQCsCKBzC2QBNB7AtCJQC3IXAAJhQAAGFjLEvQjMExlKCNQqPEfr5AAQidAAiYgLg");
	this.shape_93.setTransform(195.775,171.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#7788BF").ss(24,1,1).p("A9AkGQAAmBDEkwQDFkyFEiZQKDk0L3AAQCcAACXAMQF6AfEmDoQCsCHB2CzQBQB5AwCHQDFIPAAJgQAAGDjEEvQjFEylECZQqDE0r3AAQicAAiXgMQl6gfknjoQiriHh3iyQhPh6gwiHQjFoPAApgg");
	this.shape_94.setTransform(195.775,171.925);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.rf(["#C08D65","#FF6E77","#D6B287"],[0,0.416,1],0,0,0,0,0,206.4).s().p("Ao5arQl6gfknjoQiriHh3iyQhPh6gwiHQjFoPAApgIAAgBQAAmBDEkwQDFkyFEiZQKDk0L3AAQCcAACXAMQF6AfEmDoQCsCHB2CzQBQB5AwCHQDFIPAAJgQAAGDjEEvQjFEylECZQqDE0r3AAQicAAiXgMg");
	this.shape_95.setTransform(195.775,171.925);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#8080C6").ss(24,1,1).p("A85jsQAAl/C+kxQC+kzE9ijQJ4lLL1AAQCbAACWAOQF3AhEnDjQCsCEB5CxQBSB3A0CEQDTIIAAJeQAAGBi+ExQi+Ezk9CjQp4FLr1AAQibAAiWgOQl3ghknjjQisiEh5iwQhSh4gziEQjUoJAApeg");
	this.shape_96.setTransform(195.725,172.575);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.rf(["#C78D65","#FF6C79","#D3B58A"],[0,0.376,1],0,0,0,0,0,203.7).s().p("AodawQl3ghknjjQisiEh5iwQhSh4gziEQjUoJAApeIAAgBQAAl/C+kxQC+kzE9ijQJ4lLL1AAQCbAACWAOQF3AhEnDjQCsCEB5CxQBSB3A0CEQDTIIAAJeQAAGBi+ExQi+Ezk9CjQp4FLr1AAQibAAiWgOg");
	this.shape_97.setTransform(195.725,172.575);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#8877CC").ss(24,1,1).p("A8yjRQAAl9C3kyQC4k0E3ivQJslgLzAAQCaAACVAOQF1AkEnDeQCsCCB8CuQBVB1A2CCQDhIAABJdQgBF/i2ExQi3E0k3CvQpsFgrzAAQibAAiVgOQl0gkkojeQiriCh9itQhVh2g2iCQjioBAApdg");
	this.shape_98.setTransform(195.7,173.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.rf(["#CD8D64","#FF697A","#D0B78C"],[0,0.333,1],0,0,0,0,0,201.1).s().p("AoAa2Ql2gkknjfQiriBh9iuQhUh1g3iCQjioBAApdIAAAAQAAl+C3kxQC4k0E2iuQJslhLzAAQCbAACVAOQF1AkEmDfQCsCBB9CuQBUB1A3CCQDhIAABJdQgBF+i3EyQi3E0k3CuQpsFhryAAQibAAiUgOg");
	this.shape_99.setTransform(195.7,173.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#906FD2").ss(24,1,1).p("A8qi3QAAl7CwkzQCwk0Exi6QJgl2LxAAQCaAACUAPQFyAmEnDaQCsB/CACrQBWBzA6B/QDvH5ABJcQAAF8iwEzQiwE0kxC6QpgF2rxAAQiaAAiUgPQlygmknjaQish/iAiqQhWh0g7iAQjvn5AApcg");
	this.shape_100.setTransform(195.675,173.825);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.rf(["#D38D64","#FF677C","#CDBA8F"],[0,0.29,1],0,0,0,0,0,198.4).s().p("Anla7QlygmknjaQish/iAiqQhWh0g7iAQjvn5AApcQAAl7CwkzQCwk0Exi6QJgl2LxAAQCaAACUAPQFyAmEnDaQCsB/CACrQBWBzA6B/QDvH5ABJcQAAF8iwEzQiwE0kxC6QpgF2rxAAQiaAAiUgPg");
	this.shape_101.setTransform(195.675,173.825);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#9966D9").ss(24,1,1).p("A8iidQAAl5CpkzQCpk2EqjEQJWmNLuAAQCZAACTAQQFvApEoDVQCrB8CECpQBZBxA9B9QD9HxABJaQgBF7ioEzQiqE2kqDEQpVGNrvAAQiZAAiSgRQlwgokojWQirh7iDioQhZhyg+h9Qj9nyAApbg");
	this.shape_102.setTransform(195.65,174.475);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.rf(["#DA8E64","#FF657E","#CABD92"],[0,0.251,1],0,0,0,0,0,195.7).s().p("AnIbAQlxgoknjWQirh7iEioQhYhyg+h9Qj+nyAApbQABl5CokzQCqk2EqjEQJWmNLuAAQCZAACSAQQFwApEoDVQCrB8CECpQBYBxA+B9QD9HxAAJaQAAF7ioEzQiqE2kqDEQpVGNrvAAQiZAAiSgRg");
	this.shape_103.setTransform(195.65,174.475);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#A25DDF").ss(24,1,1).p("A8biDQAAl2Cik0QCjk3EjjPQJKmjLsAAQCZAACRARQFtAqEoDRQCrB6CHClQBcBwBBB7QELHqAAJYQAAF5iiEzQijE3kjDPQpKGjrtAAQiYAAiSgRQltgqkojSQirh5iHimQhbhvhAh7QkMnqAApag");
	this.shape_104.setTransform(195.6,175.1);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.rf(["#E08E63","#FF627F","#C7BF94"],[0,0.208,1],0,0,0,0,0,193).s().p("AmtbGQlsgqkojSQirh5iHilQhbhwhBh7QkMnqAApaQAAl3CikzQCjk3EjjPQJLmjLrAAQCZAACSARQFtArEnDQQCsB6CGClQBcBxBAB5QEMHrAAJYQAAF4iiE0QijE3kjDPQpKGjrtAAQiYAAiSgRg");
	this.shape_105.setTransform(195.6,175.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#AA55E5").ss(24,1,1).p("A8ThoQAAl1Cbk1QCck4EcjZQI/m5LqAAQCYAACRASQFqAsEoDNQCrB3CKCjQBdBtBFB4QEZHjAAJXQAAF2ibE1QicE4kcDZQo/G5rqAAQiYAAiRgSQlqgskojNQirh3iKiiQhdhuhFh5QkZnjAApXg");
	this.shape_106.setTransform(195.575,175.725);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.rf(["#E68E63","#FF6081","#C4C297"],[0,0.169,1],0,0,0,0,0,190.3).s().p("AmRbLQlqgskojNQirh3iKiiQhdhuhFh5QkZnjAApXQAAl1Cbk1QCck4EcjZQI/m5LqAAQCYAACRASQFqAsEoDNQCrB3CKCjQBdBtBFB4QEZHjAAJXQAAF2ibE1QicE4kcDZQo/G5rqAAQiYAAiRgSg");
	this.shape_107.setTransform(195.575,175.725);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#B34DEC").ss(24,1,1).p("A8MhOQAAlyCUk2QCVk5EWjlQI0nPLoAAQCXAACPATQFoAvEpDJQCrB0CNCgQBgBrBHB2QEoHbAAJVQAAF1iVE2QiUE4kWDlQo0HProAAQiXAAiQgTQlogvkojIQirh0iNigQhghshHh2QkoncAApVg");
	this.shape_108.setTransform(195.55,176.35);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.rf(["#EC8E62","#FF5E82","#C1C49A"],[0,0.125,1],0,0,0,0,0,187.7).s().p("Al0bRQlpgvknjJQish0iNifQhghshHh2QkoncAApWIAAAAQAAlzCUk1QCVk5EXjlQIznOLogBQCXABCQASQFnAvEpDJQCqB0COCgQBgBsBHB1QEnHbABJVQAAF1iVE1QiVE5kVDlQo0HOroABQiXAAiPgTg");
	this.shape_109.setTransform(195.55,176.35);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#BB44F2").ss(24,1,1).p("A8Fg0QAAlxCOk2QCOk6EQjvQIonlLmAAQCWAACPATQFlAyEoDEQCrBxCRCdQBiBqBLBzQE1HUABJUQAAFyiOE3QiOE5kQDwQonHlrnAAQiWAAiPgUQllgxkojEQirhxiRidQhihqhLh0Qk2nVAApUg");
	this.shape_110.setTransform(195.5,177);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.rf(["#F38E62","#FF5C84","#BEC79D"],[0,0.082,1],0,0,0,0,0,185).s().p("AlZbWQlkgxkpjFQirhwiQieQhjhqhLhzQk2nUAApVQABlxCNk2QCOk5EQjwQIonlLmAAQCWAACOAUQFmAxEoDEQCrBxCRCdQBiBrBLByQE1HUAAJUQAAFyiME2QiPE6kQDwQooHlrlAAQiXAAiPgUg");
	this.shape_111.setTransform(195.5,177);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#C33CF9").ss(24,1,1).p("A79gZQAAlvCGk3QCHk7EKj6QIcn7LkAAQCWAACOAUQFiA0EpDAQCqBuCVCbQBkBnBOBxQFEHMAAJSQAAFxiGE3QiIE7kJD6QodH7rkAAQiVAAiOgUQljg0kojAQirhuiUibQhkhohPhwQlDnOAApSg");
	this.shape_112.setTransform(195.5,177.625);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.rf(["#F98E61","#FF5985","#BBC99F"],[0,0.043,1],0,0,0,0,0,182.3).s().p("Ak9bcQljg0kojAQirhuiUibQhjhohPhwQlEnOAApSQAAlvCGk3QCHk7EKj6QIcn7LkAAQCWAACOAUQFiA0EoDAQCrBuCVCbQBjBnBPBxQFDHMABJSQAAFxiGE3QiIE7kKD6QocH7rjAAQiWAAiOgUg");
	this.shape_113.setTransform(195.5,177.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},17).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_39},{t:this.shape_38}]},1).to({state:[{t:this.shape_41},{t:this.shape_40}]},1).to({state:[{t:this.shape_43},{t:this.shape_42}]},1).to({state:[{t:this.shape_45},{t:this.shape_44}]},1).to({state:[{t:this.shape_47},{t:this.shape_46}]},1).to({state:[{t:this.shape_49},{t:this.shape_48}]},1).to({state:[{t:this.shape_51},{t:this.shape_50}]},1).to({state:[{t:this.shape_53},{t:this.shape_52}]},1).to({state:[{t:this.shape_55},{t:this.shape_54}]},1).to({state:[{t:this.shape_57},{t:this.shape_56}]},1).to({state:[{t:this.shape_59},{t:this.shape_58}]},1).to({state:[{t:this.shape_61},{t:this.shape_60}]},1).to({state:[{t:this.shape_63},{t:this.shape_62}]},1).to({state:[{t:this.shape_65},{t:this.shape_64}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},1).to({state:[{t:this.shape_67},{t:this.shape_66}]},10).to({state:[{t:this.shape_69},{t:this.shape_68}]},1).to({state:[{t:this.shape_71},{t:this.shape_70}]},1).to({state:[{t:this.shape_73},{t:this.shape_72}]},1).to({state:[{t:this.shape_75},{t:this.shape_74}]},1).to({state:[{t:this.shape_77},{t:this.shape_76}]},1).to({state:[{t:this.shape_79},{t:this.shape_78}]},1).to({state:[{t:this.shape_81},{t:this.shape_80}]},1).to({state:[{t:this.shape_83},{t:this.shape_82}]},1).to({state:[{t:this.shape_85},{t:this.shape_84}]},1).to({state:[{t:this.shape_87},{t:this.shape_86}]},1).to({state:[{t:this.shape_89},{t:this.shape_88}]},1).to({state:[{t:this.shape_91},{t:this.shape_90}]},1).to({state:[{t:this.shape_93},{t:this.shape_92}]},1).to({state:[{t:this.shape_95},{t:this.shape_94}]},1).to({state:[{t:this.shape_97},{t:this.shape_96}]},1).to({state:[{t:this.shape_99},{t:this.shape_98}]},1).to({state:[{t:this.shape_101},{t:this.shape_100}]},1).to({state:[{t:this.shape_103},{t:this.shape_102}]},1).to({state:[{t:this.shape_105},{t:this.shape_104}]},1).to({state:[{t:this.shape_107},{t:this.shape_106}]},1).to({state:[{t:this.shape_109},{t:this.shape_108}]},1).to({state:[{t:this.shape_111},{t:this.shape_110}]},1).to({state:[{t:this.shape_113},{t:this.shape_112}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-12,416.4,380.5);


// stage content:
(lib.intro_movil = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Bienvenido", "52px 'Lato'");
	this.text.textAlign = "center";
	this.text.lineHeight = 62;
	this.text.lineWidth = 478;
	this.text.parent = this;
	this.text.setTransform(411.55,669.4);

	this.instance = new lib.logosplash();
	this.instance.setTransform(414.5,680.65,1,1,0,0,0,196.2,163.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(23));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(580.7,1215.6,71.79999999999995,-329.4999999999999);
// library properties:
lib.properties = {
	id: 'AE3E21924F8BE947B0D872B5E9A3DCDD',
	width: 820,
	height: 1420,
	fps: 30,
	color: "#00CCFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['AE3E21924F8BE947B0D872B5E9A3DCDD'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;